#!/bin/bash 
#  apache config .
chown apache:apache -R /var/www/html
