#!/bin/bash 
#  apache config .
cd /var/www/html
chown apache:apache -R ./
