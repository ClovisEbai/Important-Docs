#!/bin/bash
# starting service
service httpd start
