#!/bin/bash
# stoping apache
rm -rf /var/www/html/*
service httpd stop
